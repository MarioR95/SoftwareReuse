package it.unisa.javat;

public class LocalException extends Exception {

	private static final long serialVersionUID = 1L;

		public LocalException(String message) {
			super(message);

		}
}
