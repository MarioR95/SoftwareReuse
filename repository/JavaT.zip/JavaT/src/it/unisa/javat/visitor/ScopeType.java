package it.unisa.javat.visitor;

public enum ScopeType {
	COMPILATIONUNIT,
	CLASSUNIT,
	METHODUNIT
}
