package punto_02;

public interface Valutabile<T> {

	T valuta();
	T minimo();
}
