package biblioteca.system;
/**
 * 
 * @author DOMENICO
 *
 */
public class Scaffale {

}
