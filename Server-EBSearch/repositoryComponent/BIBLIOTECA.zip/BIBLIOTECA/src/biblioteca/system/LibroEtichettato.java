package biblioteca.system;
/**
 * 
 * @author DOMENICO
 *
 */
public class LibroEtichettato extends Libro{

}
